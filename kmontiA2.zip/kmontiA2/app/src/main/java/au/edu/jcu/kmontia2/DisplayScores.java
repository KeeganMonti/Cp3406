package au.edu.jcu.kmontia2;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class DisplayScores extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_scores);
        MyData myData = new MyData(this);

        //calls the data from the database
        List<String> result = myData.getAll();

        System.out.println("result:" + result.toString());


        //builds the string from what is pulled from the database
        StringBuilder builder = new StringBuilder();
        for (String item : result) {
            builder.append(item).append("\n");
        }

        //creates the list that is displayed on screen
        ListView listView = findViewById(R.id.listView);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1);
        listView.setAdapter(adapter);
        adapter.addAll(result);
    }

}