package au.edu.jcu.kmontia2;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    //intent used to swap between pages.
    ActivityResultLauncher<Intent> resultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
            }
    );

    //sets the content when page is created
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    //all three classes below are used onclick by the buttons to trigger the page changes.
    public void QuizClicked(View view) {
        Intent intent = new Intent(this, RandomQuiz.class);
        resultLauncher.launch(intent);
    }
    public void SettingsClicked(View view) {
        Intent intent = new Intent(this, Settings.class);
        resultLauncher.launch(intent);
    }

    public void DisplayClicked(View view) {
        Intent intent = new Intent(this, DisplayScores.class);
        resultLauncher.launch(intent);
    }
}