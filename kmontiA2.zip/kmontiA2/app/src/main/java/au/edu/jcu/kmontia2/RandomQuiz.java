package au.edu.jcu.kmontia2;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Random;

//Sets the variables used by this page.
public class RandomQuiz extends AppCompatActivity implements View.OnClickListener {
    MyData myData;
    int score = 0;
    Button btn_one, btn_two, btn_three, btn_four;
    TextView tv_question;

    private final Question question = new Question();

    private String answer;
    private final int questionLength = question.questions.length;

    Random random;

    //When page is created sets up and zeros off the accelerometer.

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        mSensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        mSensorManager.registerListener(mSensorListener, mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER), SensorManager.SENSOR_DELAY_NORMAL);
        mAccel = 0.00f;
        mAccelCurrent = SensorManager.GRAVITY_EARTH;
        mAccelLast = SensorManager.GRAVITY_EARTH;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_random_quiz);

        random = new Random();

        //Detects the buttons sets onclick listeners for later use
        btn_one = (Button) findViewById(R.id.btn_one);
        btn_one.setOnClickListener(this);
        btn_two = (Button) findViewById(R.id.btn_two);
        btn_two.setOnClickListener(this);
        btn_three = (Button) findViewById(R.id.btn_three);
        btn_three.setOnClickListener(this);
        btn_four = (Button) findViewById(R.id.btn_four);
        btn_four.setOnClickListener(this);

        tv_question = (TextView) findViewById(R.id.tv_question);

        NextQuestion(random.nextInt(questionLength));
    }

    //Switch to detect if the answer is correct
    //detects if the max score has been reached
    @SuppressLint("NonConstantResourceId")
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_one:
                if (btn_one.getText() == answer) {
                    score += 1;
                    if (score >= 8) {
                        GameOver();
                    } else
                        Toast.makeText(RandomQuiz.this, "You Are Correct", Toast.LENGTH_SHORT).show();
                    NextQuestion(random.nextInt(questionLength));
                } else {
                    GameOver();
                }

                break;

            case R.id.btn_two:
                if (btn_two.getText() == answer) {
                    score += 1;
                    if (score >= 8) {
                        GameOver();
                    } else
                        Toast.makeText(RandomQuiz.this, "You Are Correct", Toast.LENGTH_SHORT).show();
                    NextQuestion(random.nextInt(questionLength));
                } else {
                    GameOver();
                }

                break;

            case R.id.btn_three:
                if (btn_three.getText() == answer) {
                    score += 1;
                    if (score >= 8) {
                        GameOver();
                    } else
                        Toast.makeText(RandomQuiz.this, "You Are Correct", Toast.LENGTH_SHORT).show();
                    NextQuestion(random.nextInt(questionLength));
                } else {
                    GameOver();
                }

                break;

            case R.id.btn_four:
                if (btn_four.getText() == answer) {
                    score += 1;
                    if (score >= 8) {
                        GameOver();
                    } else
                        Toast.makeText(RandomQuiz.this, "You Are Correct", Toast.LENGTH_SHORT).show();
                    NextQuestion(random.nextInt(questionLength));
                } else {
                    GameOver();
                }

                break;
        }
    }

    //Game over class gets the date and adds the date and score to the data base.
    //When GameOver is called it creates a alert box that allows the user to post on twitter
    @SuppressLint("SimpleDateFormat")
    private void GameOver() {

        Calendar calendar;
        SimpleDateFormat dateFormat;

        calendar = Calendar.getInstance();

        dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        String date = dateFormat.format(calendar.getTime());

        myData = new MyData(this);

        myData.addScore(date, score);

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(RandomQuiz.this);
        alertDialogBuilder
                .setMessage("Game Over, Your score is " + score)
                .setCancelable(false)
                .setPositiveButton("Share on Twitter", (dialog, which) -> shareOnTwitter())
                .setNegativeButton("Main Menu", (dialog, which) -> finish());
        alertDialogBuilder.show();

    }

    //Class that allows connection to Twitter, will open a web browser and go to twitter
    // will prompt the user to log in and then they can post from there
    public void shareOnTwitter() {
        String tweetUrl = String.format("https://twitter.com/intent/tweet?text=%s",
                urlEncode("I scored " + score + " on my study quiz."));
        Intent intent_twitter = new Intent(Intent.ACTION_VIEW, Uri.parse(tweetUrl));

        // Goes to Twitter App if available on device.
        @SuppressLint("QueryPermissionsNeeded") List<ResolveInfo> matches = getPackageManager().queryIntentActivities(intent_twitter, 0);
        for (ResolveInfo info : matches) {
            if (info.activityInfo.packageName.toLowerCase().startsWith("com.twitter")) {
                intent_twitter.setPackage(info.activityInfo.packageName);
            }
        }

        startActivity(intent_twitter);
    }

   //Used for twitter URL.
    public static String urlEncode(String s) {
        try {
            return URLEncoder.encode(s, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException("URLEncoder.encode() failed for " + s);
        }
    }

    //Sets the next question and sets the buttons
    private void NextQuestion(int num) {
        tv_question.setText(question.getQuestion(num));
        btn_one.setText(question.getchoice1(num));
        btn_two.setText(question.getchoice2(num));
        btn_three.setText(question.getchoice3(num));
        btn_four.setText(question.getchoice4(num));

        answer = question.getCorrectAnswer(num);
    }

    //Sensors using accelerometer that allows a new question when shaken.
    private SensorManager mSensorManager;
    private float mAccel; // acceleration apart from gravity
    private float mAccelCurrent; // current acceleration including gravity
    private float mAccelLast; // last acceleration including gravity

    private final SensorEventListener mSensorListener = new SensorEventListener() {

        public void onSensorChanged(SensorEvent se) {
            float x = se.values[0];
            float y = se.values[1];
            float z = se.values[2];
            mAccelLast = mAccelCurrent;
            mAccelCurrent = (float) Math.sqrt((double) (x * x + y * y + z * z));
            float delta = mAccelCurrent - mAccelLast;
            mAccel = mAccel * 0.9f + delta; // perform low-cut filter

            if (mAccel > 10) {
                NextQuestion(random.nextInt(questionLength));
            }
        }

        public void onAccuracyChanged(Sensor sensor, int accuracy) {
        }
    };

    @Override
    protected void onResume() {
        super.onResume();
        mSensorManager.registerListener(mSensorListener, mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER), SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    protected void onPause() {
        mSensorManager.unregisterListener(mSensorListener);
        super.onPause();
    }

}