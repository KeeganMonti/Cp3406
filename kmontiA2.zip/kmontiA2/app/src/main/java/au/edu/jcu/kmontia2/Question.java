package au.edu.jcu.kmontia2;

public class Question {

    //questions stored in a string
    public String[] questions = {
            "Which is a Programming Language?",
            "Programming language COBOL works best for use in?",
            "A loop that never ends is referred to as a(n)_________.",
            "_______ is the process of finding errors and fixing them within a program. ",
            "Within the Java language which of the following is not a required part of a for loop? ",
            "The program that translates your code from a high-level language to the binary language is called ________"
    };

    //choices for the questions stored in a string
    public String[][] choices = {
            {"HTML", "CSS", "Vala", "PHP"},
            {"Siemens Applications", "Student Applications", "Social Applications", "Commercial Applications"},
            {"While loop", "Infinite loop", "Recursive loop", ") for loop"},
            {"Compiling", "Executing", "Debugging", "Scanning"},
            {"Initialization", "Condition", "Variable", "Increment"},
            {"Programmer", "Compiler", "Translator", "Linker"}
    };

    //correct answers stored in a string
    public String[] correctAnswer = {
            "PHP",
            "Commercial Applications",
            "Infinite loop",
            "Debugging",
            "Variable",
            "Compiler"
    };

   //gets the question and the choices related to that question from the stings
    public String getQuestion(int a) {
        return questions[a];
    }

    public String getchoice1(int a) {
        return choices[a][0];
    }

    public String getchoice2(int a) {
        return choices[a][1];
    }

    public String getchoice3(int a) {
        return choices[a][2];
    }

    public String getchoice4(int a) {
        return choices[a][3];
    }

    public String getCorrectAnswer(int a) {
        return correctAnswer[a];
    }
}