package au.edu.jcu.kmontia2;

import android.annotation.SuppressLint;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class MyData extends SQLiteOpenHelper {

    //create the database and the table
    public MyData(Context context) {
        super(context, "the_database", null, 1);
    }

    @SuppressLint("SQLiteString")
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("CREATE TABLE RESULTS (DATE STRING, SCORE INTEGER);");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
    }

    //class for adding new entries to database table.
    public void addScore(String date, int score) {
        SQLiteDatabase database = this.getWritableDatabase();

        String sqlCode = "INSERT INTO RESULTS (DATE, SCORE) VALUES ("
                + "\"" + date + "\"," + score + ");";

        System.out.println(sqlCode);
        database.execSQL(sqlCode);
        database.close();
    }

    //class for retrieving from the database
    public List<String> getAll() {
        SQLiteDatabase database = this.getReadableDatabase();

        Cursor cursor = database.rawQuery("SELECT * FROM RESULTS;", null);

        List<String> result = new ArrayList<>();
        while (cursor.moveToNext()) {
            String date = cursor.getString(0);
            int score = cursor.getInt(1);
            System.out.println("data record contains: " + date + score);

            result.add(date + " Score: " + score);
        }

        cursor.close();
        database.close();

        return result;
    }
}